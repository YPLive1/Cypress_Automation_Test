/// <reference types = "Cypress"/>
describe('Infinite Scroll', () => {
  it('should load new child divs as the user scrolls down', () => {
    // Load the website
    cy.visit('http://the-internet.herokuapp.com/infinite_scroll')

    // Get the initial number of child divs
    let initialCount = 0
    cy.get('.jscroll-added').then(($divs) => {
      initialCount = $divs.length
    })

    // Scroll down to load more child divs
    cy.get('.jscroll-inner').scrollTo('bottom',{ ensureScrollable: false })
    cy.wait(2000)
    // Wait for the new child divs to be added
    cy.get('.jscroll-added').should('have.length.greaterThan', initialCount)
  })
})


