/// <reference types = "Cypress"/>
describe('Drag and Drop Elements', () => {
  it('should drag element A to element B', () => {
    // Load the website
    cy.visit('http://the-internet.herokuapp.com/drag_and_drop')

    // Get the draggable elements
    const sourceElement = cy.get('#column-a')
    const targetElement = cy.get('#column-b')

    // Perform the drag and drop action
    sourceElement.trigger('mousedown', { which: 1 })
    targetElement.trigger('mousemove').trigger('mouseup', { force: true })

    // Assert that the elements have swapped places
    cy.get('#column-a').contains('B')
    cy.get('#column-b').should('have.text', 'A')
  })
})
