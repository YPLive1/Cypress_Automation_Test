function exist(grid, word) {
    const rows = grid.length;
    const cols = grid[0].length;
    
    function dfs(row, col, index) {
      if (index === word.length) {
        return true;
      }
      
      if (row < 0 || col < 0 || row >= rows || col >= cols || grid[row][col] !== word[index]) {
        return false;
      }
      
      const temp = grid[row][col];
      grid[row][col] = '#';  // mark visited
      
      const found = dfs(row+1, col, index+1) ||
                    dfs(row-1, col, index+1) ||
                    dfs(row, col+1, index+1) ||
                    dfs(row, col-1, index+1);
      
      grid[row][col] = temp;  // unmark visited
      
      return found;
    }
    
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        if (grid[row][col] === word[0] && dfs(row, col, 0)) {
          return true;
        }
      }
    }
    
    return false;
  }
  const
    grid = [['x', 'c', 'a'],
  ['d', 'y', 't'],
  ['o', 'g', 'z']
  ];
  const word = 'cat';
  
  console.log(exist(grid, word));